﻿namespace Temperature_Converter
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_calc_1 = new System.Windows.Forms.Button();
            this.btn_calc_2 = new System.Windows.Forms.Button();
            this.btn_calc_3 = new System.Windows.Forms.Button();
            this.btn_calc_4 = new System.Windows.Forms.Button();
            this.btn_calc_5 = new System.Windows.Forms.Button();
            this.btn_calc_6 = new System.Windows.Forms.Button();
            this.btn_calc_7 = new System.Windows.Forms.Button();
            this.btn_calc_8 = new System.Windows.Forms.Button();
            this.btn_calc_9 = new System.Windows.Forms.Button();
            this.btn_calc_plusMinus = new System.Windows.Forms.Button();
            this.btn_calc_0 = new System.Windows.Forms.Button();
            this.btn_calc_dec = new System.Windows.Forms.Button();
            this.btn_calc_delete = new System.Windows.Forms.Button();
            this.btn_calc_clear = new System.Windows.Forms.Button();
            this.cmb_units_input = new System.Windows.Forms.ComboBox();
            this.cmb_units_output = new System.Windows.Forms.ComboBox();
            this.lbl_temp_input = new System.Windows.Forms.Label();
            this.lbl_convert_output = new System.Windows.Forms.Label();
            this.lbl_equal_output = new System.Windows.Forms.Label();
            this.lbl_conv_diff = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_calc_1
            // 
            this.btn_calc_1.Location = new System.Drawing.Point(750, 341);
            this.btn_calc_1.Name = "btn_calc_1";
            this.btn_calc_1.Size = new System.Drawing.Size(50, 50);
            this.btn_calc_1.TabIndex = 0;
            this.btn_calc_1.Text = "1";
            this.btn_calc_1.UseVisualStyleBackColor = true;
            this.btn_calc_1.Click += new System.EventHandler(this.number_calc);
            // 
            // btn_calc_2
            // 
            this.btn_calc_2.Location = new System.Drawing.Point(806, 341);
            this.btn_calc_2.Name = "btn_calc_2";
            this.btn_calc_2.Size = new System.Drawing.Size(50, 50);
            this.btn_calc_2.TabIndex = 1;
            this.btn_calc_2.Text = "2";
            this.btn_calc_2.UseVisualStyleBackColor = true;
            this.btn_calc_2.Click += new System.EventHandler(this.number_calc);
            // 
            // btn_calc_3
            // 
            this.btn_calc_3.Location = new System.Drawing.Point(862, 341);
            this.btn_calc_3.Name = "btn_calc_3";
            this.btn_calc_3.Size = new System.Drawing.Size(50, 50);
            this.btn_calc_3.TabIndex = 2;
            this.btn_calc_3.Text = "3";
            this.btn_calc_3.UseVisualStyleBackColor = true;
            this.btn_calc_3.Click += new System.EventHandler(this.number_calc);
            // 
            // btn_calc_4
            // 
            this.btn_calc_4.Location = new System.Drawing.Point(750, 397);
            this.btn_calc_4.Name = "btn_calc_4";
            this.btn_calc_4.Size = new System.Drawing.Size(50, 50);
            this.btn_calc_4.TabIndex = 3;
            this.btn_calc_4.Text = "4";
            this.btn_calc_4.UseVisualStyleBackColor = true;
            this.btn_calc_4.Click += new System.EventHandler(this.number_calc);
            // 
            // btn_calc_5
            // 
            this.btn_calc_5.Location = new System.Drawing.Point(806, 397);
            this.btn_calc_5.Name = "btn_calc_5";
            this.btn_calc_5.Size = new System.Drawing.Size(50, 50);
            this.btn_calc_5.TabIndex = 4;
            this.btn_calc_5.Text = "5";
            this.btn_calc_5.UseVisualStyleBackColor = true;
            this.btn_calc_5.Click += new System.EventHandler(this.number_calc);
            // 
            // btn_calc_6
            // 
            this.btn_calc_6.Location = new System.Drawing.Point(862, 397);
            this.btn_calc_6.Name = "btn_calc_6";
            this.btn_calc_6.Size = new System.Drawing.Size(50, 50);
            this.btn_calc_6.TabIndex = 5;
            this.btn_calc_6.Text = "6";
            this.btn_calc_6.UseVisualStyleBackColor = true;
            this.btn_calc_6.Click += new System.EventHandler(this.number_calc);
            // 
            // btn_calc_7
            // 
            this.btn_calc_7.Location = new System.Drawing.Point(750, 453);
            this.btn_calc_7.Name = "btn_calc_7";
            this.btn_calc_7.Size = new System.Drawing.Size(50, 50);
            this.btn_calc_7.TabIndex = 6;
            this.btn_calc_7.Text = "7";
            this.btn_calc_7.UseVisualStyleBackColor = true;
            this.btn_calc_7.Click += new System.EventHandler(this.number_calc);
            // 
            // btn_calc_8
            // 
            this.btn_calc_8.Location = new System.Drawing.Point(806, 453);
            this.btn_calc_8.Name = "btn_calc_8";
            this.btn_calc_8.Size = new System.Drawing.Size(50, 50);
            this.btn_calc_8.TabIndex = 7;
            this.btn_calc_8.Text = "8";
            this.btn_calc_8.UseVisualStyleBackColor = true;
            this.btn_calc_8.Click += new System.EventHandler(this.number_calc);
            // 
            // btn_calc_9
            // 
            this.btn_calc_9.Location = new System.Drawing.Point(862, 453);
            this.btn_calc_9.Name = "btn_calc_9";
            this.btn_calc_9.Size = new System.Drawing.Size(50, 50);
            this.btn_calc_9.TabIndex = 8;
            this.btn_calc_9.Text = "9";
            this.btn_calc_9.UseVisualStyleBackColor = true;
            this.btn_calc_9.Click += new System.EventHandler(this.number_calc);
            // 
            // btn_calc_plusMinus
            // 
            this.btn_calc_plusMinus.Location = new System.Drawing.Point(752, 509);
            this.btn_calc_plusMinus.Name = "btn_calc_plusMinus";
            this.btn_calc_plusMinus.Size = new System.Drawing.Size(50, 50);
            this.btn_calc_plusMinus.TabIndex = 9;
            this.btn_calc_plusMinus.Text = "+/-";
            this.btn_calc_plusMinus.UseVisualStyleBackColor = true;
            this.btn_calc_plusMinus.Click += new System.EventHandler(this.btn_calc_plusMinus_Click);
            // 
            // btn_calc_0
            // 
            this.btn_calc_0.Location = new System.Drawing.Point(806, 509);
            this.btn_calc_0.Name = "btn_calc_0";
            this.btn_calc_0.Size = new System.Drawing.Size(50, 50);
            this.btn_calc_0.TabIndex = 10;
            this.btn_calc_0.Text = "0";
            this.btn_calc_0.UseVisualStyleBackColor = true;
            this.btn_calc_0.Click += new System.EventHandler(this.number_calc);
            // 
            // btn_calc_dec
            // 
            this.btn_calc_dec.Location = new System.Drawing.Point(862, 509);
            this.btn_calc_dec.Name = "btn_calc_dec";
            this.btn_calc_dec.Size = new System.Drawing.Size(50, 50);
            this.btn_calc_dec.TabIndex = 11;
            this.btn_calc_dec.Text = ".";
            this.btn_calc_dec.UseVisualStyleBackColor = true;
            this.btn_calc_dec.Click += new System.EventHandler(this.number_calc);
            // 
            // btn_calc_delete
            // 
            this.btn_calc_delete.Location = new System.Drawing.Point(750, 285);
            this.btn_calc_delete.Name = "btn_calc_delete";
            this.btn_calc_delete.Size = new System.Drawing.Size(83, 50);
            this.btn_calc_delete.TabIndex = 12;
            this.btn_calc_delete.Text = "Delete";
            this.btn_calc_delete.UseVisualStyleBackColor = true;
            this.btn_calc_delete.Click += new System.EventHandler(this.btn_calc_delete_Click);
            // 
            // btn_calc_clear
            // 
            this.btn_calc_clear.Location = new System.Drawing.Point(839, 285);
            this.btn_calc_clear.Name = "btn_calc_clear";
            this.btn_calc_clear.Size = new System.Drawing.Size(73, 50);
            this.btn_calc_clear.TabIndex = 13;
            this.btn_calc_clear.Text = "Clear";
            this.btn_calc_clear.UseVisualStyleBackColor = true;
            this.btn_calc_clear.Click += new System.EventHandler(this.btn_calc_clear_Click);
            // 
            // cmb_units_input
            // 
            this.cmb_units_input.FormattingEnabled = true;
            this.cmb_units_input.Location = new System.Drawing.Point(451, 215);
            this.cmb_units_input.Name = "cmb_units_input";
            this.cmb_units_input.Size = new System.Drawing.Size(121, 21);
            this.cmb_units_input.TabIndex = 14;
            this.cmb_units_input.DropDownClosed += new System.EventHandler(this.UpdateOutputHelper);
            // 
            // cmb_units_output
            // 
            this.cmb_units_output.FormattingEnabled = true;
            this.cmb_units_output.Location = new System.Drawing.Point(451, 314);
            this.cmb_units_output.Name = "cmb_units_output";
            this.cmb_units_output.Size = new System.Drawing.Size(121, 21);
            this.cmb_units_output.TabIndex = 15;
            this.cmb_units_output.DropDownClosed += new System.EventHandler(this.UpdateOutputHelper);
            // 
            // lbl_temp_input
            // 
            this.lbl_temp_input.AutoSize = true;
            this.lbl_temp_input.Location = new System.Drawing.Point(448, 180);
            this.lbl_temp_input.Name = "lbl_temp_input";
            this.lbl_temp_input.Size = new System.Drawing.Size(13, 13);
            this.lbl_temp_input.TabIndex = 16;
            this.lbl_temp_input.Text = "0";
            // 
            // lbl_convert_output
            // 
            this.lbl_convert_output.AutoSize = true;
            this.lbl_convert_output.Location = new System.Drawing.Point(449, 285);
            this.lbl_convert_output.Name = "lbl_convert_output";
            this.lbl_convert_output.Size = new System.Drawing.Size(13, 13);
            this.lbl_convert_output.TabIndex = 17;
            this.lbl_convert_output.Text = "0";
            // 
            // lbl_equal_output
            // 
            this.lbl_equal_output.AutoSize = true;
            this.lbl_equal_output.Location = new System.Drawing.Point(448, 378);
            this.lbl_equal_output.Name = "lbl_equal_output";
            this.lbl_equal_output.Size = new System.Drawing.Size(82, 13);
            this.lbl_equal_output.TabIndex = 18;
            this.lbl_equal_output.Text = "About equal to: ";
            // 
            // lbl_conv_diff
            // 
            this.lbl_conv_diff.AutoSize = true;
            this.lbl_conv_diff.Location = new System.Drawing.Point(448, 416);
            this.lbl_conv_diff.Name = "lbl_conv_diff";
            this.lbl_conv_diff.Size = new System.Drawing.Size(86, 13);
            this.lbl_conv_diff.TabIndex = 19;
            this.lbl_conv_diff.Text = "Temp Difference";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkKhaki;
            this.ClientSize = new System.Drawing.Size(1210, 626);
            this.Controls.Add(this.lbl_conv_diff);
            this.Controls.Add(this.lbl_equal_output);
            this.Controls.Add(this.lbl_convert_output);
            this.Controls.Add(this.lbl_temp_input);
            this.Controls.Add(this.cmb_units_output);
            this.Controls.Add(this.cmb_units_input);
            this.Controls.Add(this.btn_calc_clear);
            this.Controls.Add(this.btn_calc_delete);
            this.Controls.Add(this.btn_calc_dec);
            this.Controls.Add(this.btn_calc_0);
            this.Controls.Add(this.btn_calc_plusMinus);
            this.Controls.Add(this.btn_calc_9);
            this.Controls.Add(this.btn_calc_8);
            this.Controls.Add(this.btn_calc_7);
            this.Controls.Add(this.btn_calc_6);
            this.Controls.Add(this.btn_calc_5);
            this.Controls.Add(this.btn_calc_4);
            this.Controls.Add(this.btn_calc_3);
            this.Controls.Add(this.btn_calc_2);
            this.Controls.Add(this.btn_calc_1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_calc_1;
        private System.Windows.Forms.Button btn_calc_2;
        private System.Windows.Forms.Button btn_calc_3;
        private System.Windows.Forms.Button btn_calc_4;
        private System.Windows.Forms.Button btn_calc_5;
        private System.Windows.Forms.Button btn_calc_6;
        private System.Windows.Forms.Button btn_calc_7;
        private System.Windows.Forms.Button btn_calc_8;
        private System.Windows.Forms.Button btn_calc_9;
        private System.Windows.Forms.Button btn_calc_plusMinus;
        private System.Windows.Forms.Button btn_calc_0;
        private System.Windows.Forms.Button btn_calc_dec;
        private System.Windows.Forms.Button btn_calc_delete;
        private System.Windows.Forms.Button btn_calc_clear;
        private System.Windows.Forms.ComboBox cmb_units_input;
        private System.Windows.Forms.ComboBox cmb_units_output;
        private System.Windows.Forms.Label lbl_temp_input;
        private System.Windows.Forms.Label lbl_convert_output;
        private System.Windows.Forms.Label lbl_equal_output;
        private System.Windows.Forms.Label lbl_conv_diff;
    }
}

